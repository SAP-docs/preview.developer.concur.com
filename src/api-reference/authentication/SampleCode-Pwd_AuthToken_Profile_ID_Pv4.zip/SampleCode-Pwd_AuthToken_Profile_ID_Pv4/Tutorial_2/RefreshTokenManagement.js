/** 
 * Tutorial 2 - Token Management
 * =============================
 * 
 * Purpose: Adds refresh token management automation to the previous tutorial using an external json file.
 * 
 * 
 * Method: Uses timestamps and a json file to manage refresh token expiration.
 * 
 * 
 * Required:
 * - SAP Concur instance credentials
 * - NodeJs
 * 
 * 
 * This app uses your credentials to access APIs using the following flow:
 * - Company Request Token -> Refresh token
 *
 *  
 * Company Request Token -> Refresh token:
 * 1. Company Request Token:
 *  - Generate your company request token using the Concur Admin Panel.
 *    - Used to generate a refresh token.
 *    - Token lifetime = 24 hours.
 *    - Multiple use.
 * 
 * 2. Refresh token:
 *  - Generate a refresh token using this app.
 *    - Used to generate a bearer token.
 *    - Token lifetime = 6 months.
 *    - Multiple use.
 * 
 * 
 * Procedure:
 * 1. Login to your Concur Admin panel at https://www.concursolutions.com/nui/authadmin/companytokens
 * 2. Generate your Company Request Token using your App ID.
 * 3. Copy/paste the Company UUID and Company Request Token fields to a text file.
 * 4. Run the app to generate the credentials.json file.
 * 5. Fill in the empty fields in this file with your credentials.
 * 6. Run the app again. The app will call the getProfileFromID v4 API call using your credentials.
 * 
 * 
 * Check Debug Output (Without a refresh token):
 * 1. Your credentials are transferred from the JSON file to the credentials object. 
 * 2. A validity check on the credentials object is performed.
 * 3. If the validity check is successful the company request token in the credentialsObject is used to make an API call to get the refresh token.
 * 4. If the API call is successful, the refresh token data is converted from JSON format into a refresh token object.
 * 5. The refresh token object is stored in the file refreshTokenObjectFile.json.
 * 
 * 
 * Check Debug Output (While refresh token is valid):
 * 1. Your credentials are transferred from the JSON file to the credentials object. 
 * 2. A validity check on the credentials object is performed.
 * 3. If the validity check is successful, the refresh token is loaded from the file refreshTokenObjectFile.json and converted into a refresh token object.
 * 4. A validity check on the refresh token object is performed.
 * 5. If the validity check is successful, the refresh token in the refresh token object can be used to make an API call to get a bearer token.
 * 
 * 
 * */   


const https = require('https');
const querystring = require('querystring');
const util = require('util');
const fs = require('fs');
const path = require('path');

const credentialsFileName = "credentials.json";
const savedCredentialsPathFileName = path.resolve(__dirname, credentialsFileName);
const refreshTokenObjectFileName = "refreshTokenObjectFile.json";
const savedRefreshTokenObjectPathFileName = path.resolve(__dirname, refreshTokenObjectFileName);
console.log(savedCredentialsPathFileName);
console.log(savedRefreshTokenObjectPathFileName);

var refreshTokenObject = '';
var refreshTokenExpiresInTimestamp = ''
var refreshTokenExpiresInDate = ''
var dataRetrieved = '';
var credentialsObject = new Object();


function createCredentialsObjectTemplate() {
  // postData object
  credentialsObject.appID = "";
  credentialsObject.clientSecret = "";
  credentialsObject.grantType = "password";
  credentialsObject.companyUUID = "";
  credentialsObject.companyRequestToken = "";
  credentialsObject.credentialType = "authtoken";
  console.log("Created Credentials Object template.")
}

function readCredentialsFile() {
  fs.readFile(savedCredentialsPathFileName, "utf8", (err, jsonString) => {
    if (err) {
      console.log("Error reading file from disk:", err);
      console.log("No credentials found.");
      createCredentialsObjectTemplate();
      writeCredentialsFile();
      return;
    }
    try {
      credentialsObject = JSON.parse(jsonString);
      console.log("credentialsObject Object: ");
      console.log(util.inspect(credentialsObject, { showHidden: false, depth: null, colors: true }));
      if (credentialsObject.appID != "") {
        console.log("Credentials object is valid. Checking for refresh token.");
        readRefreshTokenObjectFile();
      }
      else {
        console.log("Invalid credentials object. Please fill in all required fields in credentials.json");
      }
      
    } catch (err) {
      console.log("Error parsing JSON string:", err);
      createCredentialsObjectTemplate();
      writeCredentialsFile();
      return;
    }
  });
}

function writeCredentialsFile() {
  console.log("Attempting to create new credentials.json file.")
  const jsonString = JSON.stringify(credentialsObject)
  fs.writeFile(savedCredentialsPathFileName, jsonString, err => {
      if (err) {
        console.log('Error writing file', err);
      } else {
        console.log('Successfully wrote credentials.json file to the app folder using the credentials object template.');
        console.log("Add your credentials to this file and run the app again.");
        console.log("credentialsObject Object: ");
        console.log(util.inspect(credentialsObject, { showHidden: false, depth: null, colors: true }));
      }
  })
}

function readRefreshTokenObjectFile() {
  fs.readFile(savedRefreshTokenObjectPathFileName, "utf8", (err, jsonString) => {
    if (err) {
      console.log("Error reading file from disk:", err);
      console.log("No stored refresh token found.");
      getAuthTokenAuthKey();
      return;
    }
    try {
      refreshTokenObject = JSON.parse(jsonString);
      refreshTokenObject.companyUUID = credentialsObject.companyUUID;

      console.log("Company UUID = " + refreshTokenObject.companyUUID);
      console.log("Refresh Token Object: ");
      console.log(util.inspect(refreshTokenObject, { showHidden: false, depth: null, colors: true }));
      
      checkDateAndTime();
    } catch (err) {
      console.log("Error parsing JSON string:", err);
      getAuthTokenAuthKey();
      return;
    }
  });
}

function writeRefreshTokenObjectFile() {
  const jsonString = JSON.stringify(refreshTokenObject)
  fs.writeFile(savedRefreshTokenObjectPathFileName, jsonString, err => {
      if (err) {
        console.log('Error writing file', err);
      } else {
        console.log('Successfully wrote file');
        readRefreshTokenObjectFile();
      }
  })
}

function checkDateAndTime() {
  refreshTokenExpiresInTimestamp = refreshTokenObject.refresh_expires_in
  const dateInUNIXtimestamp = new Date(refreshTokenExpiresInTimestamp);
  console.log("refresh_expires_in Timestamp = " + dateInUNIXtimestamp.getTime());

  // Multiplied by 1,000 to transform timestamp to milliseconds as a date.
  const refreshTokenTimestampConvertedToDate = new Date(refreshTokenExpiresInTimestamp * 1000);
  
  refreshTokenExpiresInDate = refreshTokenTimestampConvertedToDate.toLocaleDateString("en-US");
  console.log("Refresh token expires on " + refreshTokenExpiresInDate);
  console.log("Refresh token expires on " + refreshTokenTimestampConvertedToDate);

  const currentDate = new Date();
  var currentDateConvertedToLocale = currentDate.toLocaleDateString("en-US");
  console.log("currentDate = " + currentDate);
  console.log("currentDateConvertedToLocale = " + currentDateConvertedToLocale);

  var refreshTokenTimeRemainingInMilliseconds = refreshTokenTimestampConvertedToDate - currentDate;
  console.log("Refresh token expires in " + refreshTokenTimeRemainingInMilliseconds + " milliseconds.")

  console.log("End checkDateAndTime.")

  checkForRefreshTokenDateExpiry(refreshTokenTimestampConvertedToDate, currentDate);
}

function checkForRefreshTokenDateExpiry(date1, date2){
    if(date1 > date2){
      console.log("Refresh token is valid. Using existing token to make API Calls.");
    } else if(date1 < date2){
      console.log("Refresh token is invalid. Getting a new refresh token.");
      getAuthTokenAuthKey();
    } else{
      console.log("Refresh token is invalid. Getting a new refresh token.");
      getAuthTokenAuthKey();
    }
  console.log("End checkForRefreshTokenDateExpiry.")
}

function getAuthTokenAuthKey() {
  console.log("Getting refresh token using AuthTokenAuthKey flow");
  
  // form data
  var postData = querystring.stringify({
    client_id: credentialsObject.appID,
    client_secret: credentialsObject.clientSecret,
    grant_type: credentialsObject.grantType,
    username: credentialsObject.companyUUID,
    password: credentialsObject.companyRequestToken,
    credtype: credentialsObject.credentialType
  });
  
  // request option
  var options = {
    host: 'us.api.concursolutions.com',
    method: 'POST',
    path: '/oauth2/v0/token',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
      'Content-Length': postData.length
    }
  };

  // request object
  var req = https.request(options, res => {
    var result = '';
    var users = '';
    res.on('data', function (chunk) {
      result += chunk;
    });
    res.on('end', function () {
      console.log("Status code = " + res.statusCode)
      dataRetrieved = JSON.parse(result);

      // Store this refresh token. Use this refresh token to call APIs.
      refreshTokenObject = dataRetrieved
      refreshTokenObject.companyUUID = credentialsObject.companyUUID;

      console.log("Company UUID = " + refreshTokenObject.companyUUID);
      console.log("Refresh Token Object: ");
      console.log(util.inspect(refreshTokenObject, { showHidden: false, depth: null, colors: true }));

      if (res.statusCode == 200) {
        storeRefreshTokenObject();
      }
      else {
        console.log("Authentication Error. Please correct.");
      }
    });
    res.on('error', function (err) {
      console.log(err);
    })
  });

  // request error
  req.on('error', function (err) {
    console.log(err);
  });
  
  //send request with the postData form
  req.write(postData);
  req.end();
}

function storeRefreshTokenObject() {
  // Store all the details of the response.
  writeRefreshTokenObjectFile();
}


// Starts App
readCredentialsFile();
