#!/usr/bin/env bash

if ! command -v newman &> /dev/null
then
    echo "newman could not be found"
    echo
    echo "Install newman with:"
    echo
    echo "    brew install newman"
    echo "or"
    echo "    npm i -g newman"
    echo
    echo "See https://github.com/postmanlabs/newman for details"
    exit 1
fi


# -k is needed to ignore self-signed certificate errors
# newman run -k -e postman/vendor-env.postman_environment.json postman/vendor-tests.postman_collection.json
# if [ "$?" != "0" ]
# then
#     exit "$?"
# fi

# Run the search query with locations from test data
newman run -k \
    --folder "shop" \
    -d data/shop_inputs.csv \
    --bail \
    -e postman/vendor-env.postman_environment.json \
    postman/vendor-tests.postman_collection.json

newman run -k \
    --folder "shop" \
    --folder "book" \
    --bail \
    -d data/book_inputs.csv \
    -e postman/vendor-env.postman_environment.json \
    postman/vendor-tests.postman_collection.json
