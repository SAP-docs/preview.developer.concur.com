ECHO OFF

:: This script will execute taurus-config.yaml on a windows computer
:: Prerequisites include java and taurus
:: This script requires a hostname as url agianst which taurus performance tests will be run

SET url=%1
SET auth_token=%2

if not defined url (
    set /P url="Please enter base url: "
    if not defined url (
        echo Missing parameter base-url!
        EXIT /B 1
    ) else (
        goto :RunTaurus
    )
) else (
    echo url is %url%
)

if not defined auth_token (
    set /P auth_token="Please enter auth_token "
    if not defined auth_token (
        echo Missing parameter auth_token!
        EXIT /B 1
    ) else (
        goto :RunTaurus
    )
) else (
    echo auth_token is %auth_token%
)

:RunTaurus
echo provided url is %url%.
echo provided auth_token is %auth_token%.
bzt -o settings.env.BASEURL=%url% -o settings.env.AUTH_TOKEN=%auth_token% scripts/taurus-config-win.yml

EXIT /B 0
