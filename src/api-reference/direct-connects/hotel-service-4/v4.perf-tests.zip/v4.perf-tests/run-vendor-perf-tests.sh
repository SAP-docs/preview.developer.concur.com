#!/usr/bin/env bash

# the script will take base urlas input and run jmeter tests
# if no input is passed then errors out 
BASE_URL="$1"
AUTH_TOKEN="$2"

if [ -z "$BASE_URL" ]
then
    echo Missing parameter - Base Url
    exit 1
fi
if [ -z "$AUTH_TOKEN" ]
then
    echo Missing parameter - Authetication Token
    exit 1
fi
bzt -o settings.env.BASEURL="$BASE_URL" \
    -o settings.env.AUTH_TOKEN="$AUTH_TOKEN" \
    scripts/taurus-config.yml
