#!/usr/bin/env bash

# the script will take base urlas input and run jmeter tests
# if no input is passed then errors out 
BASE_URL="$1"

if [ -z "$BASE_URL" ]
then
    echo Missing parameter - Base Url
    exit 1
fi

bzt -o settings.env.BASEURL="$BASE_URL" scripts/taurus-config.yml
