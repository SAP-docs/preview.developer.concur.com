# Usage

Performance scripts contained in this package for testing HSv4 endpoints uses [Taurus](https://gettaurus.org/) with [JMeter](https://jmeter.apache.org/)

## Taurus
Taurus (bzt) is a command line based tool/framework assists in automating test scripts. Taurus installation instructions are [here](https://gettaurus.org/install/Installation/)

## JMeter
Performance test scripts are composed with the help of JMeter. Starting Taurus should take care of downloading required JMeter version but in case of connectivity issues, please follow the latest [JMeter installation instructions](https://jmeter.apache.org/download_jmeter.cgi) to install JMeter locally.
JMeter also needs a working installation of Java (JVM)

## Run performance tests
* Ensure Taurus, JMeter and Java are installed and available.
* run-vendor-perf-tests.sh is the script to run these tests locally.
* The script takes as input `base_url` i.e. the vendor endpoint but without `https:` protocol in front. If the argument to the `run-vendor-perf-tests` script is missing then an error is thrown. Note that currently JMX script assumes URL to be `https` type, but possible to modify JMX script to use `http` instead.

For linux and MacOS :

```
    ./run-vendor-perf-tests.sh "<base_url>"
where <base_url> should be of the form HOST/BASE_PATH without `https` protocol
```

For windows :

Double click on the `run-vendor-perf-tests.bat` file and enter the host/base url when prompted.
OR run the following command in command prompt.
```
    .\run-vendor-perf-tests.bat <base_url>
where <base_url> should be of the form HOST/BASE_PATH without `https` protocol

```

* After the script executes, jmeter is automatically installed in the newly created `execution` folder.
* Taurus report is logged on the console.
* Jmeter's html report `index.html` is generated in the reports/\<current-date> folder.

## Booking endpoints

* In order to tests booking endpoints - please make sure to add booking payment information in `vendor-perf-tests/data/hs4-vendor-payment-inputs.csv` before running the tests.
* Refer to the table below for example values to all fields in the csv. NOTE: Fields which contain ** are the required fields in the schema to make the requests.

| Parameters       | Description                                                                                            |   Example value                         |  
| -------------------------| -------------------------------------------------------------------------------------------------------|-----------------------------------------|
| cardType **               | PaymentCardType.  | VISA. |
| cardNumber **              | Payment card number corresponding to the card type | 4242-4242-4242-4242 |
| cvv                     | Card Verification Value - three or four-digit number on credit card for security | 369 |
| cardHolderName          | Name of the card holder     | John Smith |
| addressLines            | Address of the card holder | 910 Mainland Street |
| city **            | City name             | Vancouver |
| state                   | Two-character state code      | BC |
| countryCode **            | Two-character ISO code (ISO ALPHA-2) for country.  | CA |
| postalCode      |       Postcal code                | V5K 0A1 |
| programCode **    |       programCode                   | EM.  |
| accoundId **      |       account ID                    | 209875030. |